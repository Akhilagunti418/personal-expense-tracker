const API = "/api/expenses";
const $ = (selector) => document.querySelector(selector);
const form = $("#expense-form");
const expenseList = $("#expense-list");
const formMessage = $("#form-message");
const pageMessage = $("#page-message");
const saveButton = $("#save-button");
const categoryIcons = { Food: "🍜", Transport: "🚌", Shopping: "🛍️", Bills: "🧾", Health: "💊", Education: "📚", Entertainment: "🎬", Other: "💳" };
let expenses = [];
let editingId = null;
let pendingDeleteId = null;
let requestInProgress = false;

function localDateString(date = new Date()) {
  const local = new Date(date.getTime() - date.getTimezoneOffset() * 60000);
  return local.toISOString().slice(0, 10);
}
function money(value) {
  return new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", minimumFractionDigits: 2 }).format(Number(value || 0));
}
function escapeHTML(value) {
  return String(value ?? "").replace(/[&<>"']/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[char]);
}
function showFormMessage(message, isError = false) {
  formMessage.textContent = message;
  formMessage.classList.toggle("error", isError);
}
function showPageMessage(message) {
  pageMessage.textContent = message;
  pageMessage.classList.toggle("hidden", !message);
}
async function apiRequest(url, options = {}) {
  const response = await fetch(url, { ...options, headers: { "Content-Type": "application/json", ...(options.headers || {}) } });
  const body = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(body.error || `Request failed (${response.status})`);
  return body;
}
function selectedMonth() { return $("#month-filter").value; }
function filteredExpenses() {
  const month = selectedMonth();
  const category = $("#category-filter").value;
  const query = $("#search-filter").value.trim().toLowerCase();
  return expenses.filter((item) => (!month || item.expense_date.startsWith(month)) && (!category || item.category === category) &&
    (!query || `${item.title} ${item.category} ${item.notes || ""} ${item.payment_method}`.toLowerCase().includes(query)));
}
function renderSummary() {
  const list = filteredExpenses();
  const total = list.reduce((sum, item) => sum + Number(item.amount), 0);
  $("#total-spent").textContent = money(total);
  $("#transaction-count").textContent = String(list.length);
  const byCategory = {};
  list.forEach((item) => { byCategory[item.category] = (byCategory[item.category] || 0) + Number(item.amount); });
  const top = Object.entries(byCategory).sort((a, b) => b[1] - a[1])[0];
  $("#top-category").textContent = top ? top[0] : "—";
  $("#top-category-note").textContent = top ? `${money(top[1])} spent` : "No spending yet";
}
function renderExpenses() {
  const list = filteredExpenses();
  $("#results-count").textContent = `${list.length} ${list.length === 1 ? "expense" : "expenses"}`;
  if (!list.length) {
    expenseList.innerHTML = `<div class="empty-state"><div class="empty-icon">🌱</div><strong>No expenses found</strong>Try another filter or add your first expense.</div>`;
    renderSummary();
    return;
  }
  expenseList.innerHTML = list.map((item) => `
    <article class="expense-item">
      <div class="category-icon" aria-hidden="true">${categoryIcons[item.category] || "💳"}</div>
      <div class="expense-main">
        <div class="expense-title">${escapeHTML(item.title)}</div>
        <div class="expense-meta"><span>${escapeHTML(item.expense_date)}</span><span>·</span><span class="category-tag">${escapeHTML(item.category)}</span><span>·</span><span>${escapeHTML(item.payment_method)}</span></div>
        ${item.notes ? `<div class="expense-meta">${escapeHTML(item.notes)}</div>` : ""}
      </div>
      <div class="expense-right">
        <div class="expense-amount">${money(item.amount)}</div>
        <div class="expense-actions"><button class="text-action" data-action="edit" data-id="${escapeHTML(item.id)}">Edit</button><button class="text-action delete" data-action="delete" data-id="${escapeHTML(item.id)}">Delete</button></div>
      </div>
    </article>`).join("");
  renderSummary();
}
async function loadExpenses() {
  expenseList.innerHTML = '<div class="loading-state">Loading your expenses…</div>';
  showPageMessage("");
  try {
    const data = await apiRequest(API);
    expenses = data.data;
    renderExpenses();
    $("#connection-status").textContent = "Database connected";
    $("#connection-status").className = "status-pill ok";
  } catch (error) {
    expenseList.innerHTML = '<div class="empty-state"><strong>Could not load expenses</strong>Check your server and Supabase configuration, then refresh.</div>';
    showPageMessage(error.message);
    $("#connection-status").textContent = "Connection issue";
    $("#connection-status").className = "status-pill bad";
  }
}
function resetForm() {
  form.reset();
  $("#expense-date").value = localDateString();
  $("#category").value = "Food";
  $("#payment-method").value = "UPI";
  editingId = null;
  $("#form-title").textContent = "Add an expense";
  saveButton.textContent = "Save expense";
  $("#cancel-edit").classList.add("hidden");
  showFormMessage("");
}
function beginEdit(id) {
  const item = expenses.find((expense) => expense.id === id);
  if (!item) return;
  editingId = id;
  $("#title").value = item.title;
  $("#amount").value = item.amount;
  $("#category").value = item.category;
  $("#expense-date").value = item.expense_date;
  $("#payment-method").value = item.payment_method;
  $("#notes").value = item.notes || "";
  $("#form-title").textContent = "Edit expense";
  saveButton.textContent = "Update expense";
  $("#cancel-edit").classList.remove("hidden");
  showFormMessage("");
  $("#title").focus();
  $(".form-panel").scrollIntoView({ behavior: "smooth", block: "start" });
}
form.addEventListener("submit", async (event) => {
  event.preventDefault();
  if (requestInProgress) return;
  const payload = {
    title: $("#title").value.trim(),
    amount: Number($("#amount").value),
    category: $("#category").value,
    expense_date: $("#expense-date").value,
    payment_method: $("#payment-method").value,
    notes: $("#notes").value.trim() || null
  };
  if (!payload.title || payload.title.length > 100 || !Number.isFinite(payload.amount) || payload.amount <= 0 || !payload.expense_date) {
    showFormMessage("Enter a name, a positive amount, and a valid date.", true);
    return;
  }
  const wasEditing = editingId !== null;
  requestInProgress = true;
  saveButton.disabled = true;
  saveButton.textContent = editingId ? "Updating…" : "Saving…";
  try {
    await apiRequest(editingId ? `${API}/${encodeURIComponent(editingId)}` : API, {
      method: editingId ? "PUT" : "POST", body: JSON.stringify(payload)
    });
    resetForm();
    await loadExpenses();
    showFormMessage(wasEditing ? "Expense updated." : "Expense saved.");
  } catch (error) {
    showFormMessage(error.message, true);
  } finally {
    requestInProgress = false;
    saveButton.disabled = false;
    if (editingId === null && saveButton.textContent.endsWith("…")) saveButton.textContent = "Save expense";
    if (editingId !== null) saveButton.textContent = "Update expense";
  }
});
expenseList.addEventListener("click", (event) => {
  const button = event.target.closest("button[data-action]");
  if (!button) return;
  const id = button.dataset.id;
  if (button.dataset.action === "edit") beginEdit(id);
  if (button.dataset.action === "delete") {
    pendingDeleteId = id;
    $("#delete-dialog").showModal();
  }
});
$("#confirm-delete").addEventListener("click", async (event) => {
  event.preventDefault();
  if (!pendingDeleteId) return;
  const id = pendingDeleteId;
  $("#confirm-delete").disabled = true;
  try {
    await apiRequest(`${API}/${encodeURIComponent(id)}`, { method: "DELETE" });
    $("#delete-dialog").close();
    pendingDeleteId = null;
    if (editingId === id) resetForm();
    await loadExpenses();
  } catch (error) {
    $("#delete-dialog").close();
    showPageMessage(error.message);
  } finally {
    $("#confirm-delete").disabled = false;
  }
});
$("#cancel-edit").addEventListener("click", resetForm);
$("#refresh-button").addEventListener("click", loadExpenses);
["month-filter", "category-filter", "search-filter"].forEach((id) => $(`#${id}`).addEventListener(id === "search-filter" ? "input" : "change", renderExpenses));

async function checkHealth() {
  try {
    const result = await apiRequest("/api/health");
    if (result.database === "connected") {
      $("#connection-status").textContent = "Database connected";
      $("#connection-status").className = "status-pill ok";
    } else {
      $("#connection-status").textContent = "Database not configured";
      $("#connection-status").className = "status-pill bad";
    }
  } catch {
    $("#connection-status").textContent = "Server unavailable";
    $("#connection-status").className = "status-pill bad";
  }
}
$("#month-filter").value = localDateString().slice(0, 7);
$("#expense-date").value = localDateString();
checkHealth();
loadExpenses();
