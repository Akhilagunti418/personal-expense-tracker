-- Personal Expense Tracker: Supabase PostgreSQL schema
-- Run this entire file in Supabase Dashboard -> SQL Editor -> New query.
-- This MVP is a single-user/local demo: anyone who can reach the app can manage
-- the shared expenses. Do not expose this deployment publicly without adding
-- authentication and per-user authorization (see README Security section).

create extension if not exists pgcrypto;

create table if not exists public.expenses (
  id uuid primary key default gen_random_uuid(),
  title varchar(100) not null check (char_length(trim(title)) between 1 and 100),
  amount numeric(10, 2) not null check (amount > 0),
  category varchar(20) not null check (
    category in ('Food', 'Transport', 'Shopping', 'Bills', 'Health', 'Education', 'Entertainment', 'Other')
  ),
  expense_date date not null,
  payment_method varchar(20) not null default 'UPI' check (
    payment_method in ('UPI', 'Cash', 'Card', 'Bank transfer', 'Other')
  ),
  notes varchar(500),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists expenses_expense_date_idx on public.expenses (expense_date desc);
create index if not exists expenses_category_idx on public.expenses (category);
create index if not exists expenses_created_at_idx on public.expenses (created_at desc);

create or replace function public.set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists set_expenses_updated_at on public.expenses;
create trigger set_expenses_updated_at
before update on public.expenses
for each row execute function public.set_updated_at();

-- Browser clients have no direct database credentials; the Express server uses
-- its server-only secret key. RLS is enabled as defense-in-depth. No anon/auth
-- policies are created, so direct client-role access is denied by default.
alter table public.expenses enable row level security;

-- Optional demo row: uncomment to seed one sample expense.
-- insert into public.expenses (title, amount, category, expense_date, payment_method, notes)
-- values ('Demo lunch', 180.00, 'Food', current_date, 'UPI', 'Replace or delete this sample.');
