# Personal Expense Tracker

A beginner-friendly full-stack expense tracker built with HTML, CSS, Vanilla JavaScript, Node.js, Express.js, and Supabase PostgreSQL.

## 1. Overview

Personal Expense Tracker helps a person record everyday spending, organize expenses by category, and review spending for a selected month. The dashboard calculates the total, number of transactions, and highest-spend category from database records.

### Problem statement

Small purchases are easy to forget, making it difficult to understand monthly spending. This app provides one place to record, find, update, and remove expenses.

### Target users and roles

- **MVP user:** a student or individual tracking their own spending.
- **Roles:** no login/role system is included in this learning MVP. The data is shared by everyone who can access the running app. Do not host it publicly or store private financial data until authentication and per-user authorization are added.

## 2. Features

- Create an expense with title, amount, category, date, payment method, and optional notes.
- List expenses from Supabase PostgreSQL.
- Edit and delete expenses, with a confirmation dialog for deletion.
- Filter by month and category; search title, category, notes, and payment method.
- Monthly total, transaction count, and top category summary.
- Responsive layout, form validation, loading/empty/error states.
- Express health endpoint and server-side input validation.

### Not included in this MVP

- User registration/login, multi-user isolation, recurring expenses, budgets, income tracking, exports, charts, and deployment automation.
- This version is designed for local learning/demo use. It is not a secure multi-user financial service.

## 3. Technology stack

- HTML5, CSS3, Vanilla JavaScript
- Node.js 20 or newer and Express 5
- Supabase PostgreSQL, accessed from the server using `@supabase/supabase-js`
- `dotenv` for environment variables and `helmet` for HTTP security headers

## 4. Folder structure

```text
personal-expense-tracker/
├── frontend/
│   ├── index.html
│   ├── styles.css
│   └── app.js
├── backend/
│   ├── middleware/
│   │   └── error-handler.js
│   ├── routes/
│   │   └── expenses.js
│   ├── .env                 # local placeholder; ignored by Git
│   ├── .env.example
│   ├── .gitignore
│   ├── package.json
│   ├── server.js
│   └── supabase.js
├── database/
│   └── schema.sql
├── .gitignore
└── README.md
```

## 5. Prerequisites and installation links

Install these tools on Windows:

1. **Visual Studio Code:** https://code.visualstudio.com/
2. **Node.js LTS (includes npm):** https://nodejs.org/
3. **Git:** https://git-scm.com/downloads
4. A free Supabase account: https://supabase.com/

Verify in a new VS Code terminal:

```powershell
node --version
npm --version
git --version
```

Use Node.js 20 or newer. Each command should print a version number.

## 6. Create a Supabase project

1. Sign in at https://supabase.com/ and create a new project.
2. Save the database password somewhere private. This project does not need the database password directly.
3. Wait until the database is ready.
4. Open **SQL Editor** in the Supabase dashboard and choose **New query**.
5. Open `database/schema.sql` from this project, copy the full contents, paste it into the SQL Editor, and click **Run**.
6. In **Table Editor**, verify that the `expenses` table exists and has the expected columns: `id`, `title`, `amount`, `category`, `expense_date`, `payment_method`, `notes`, `created_at`, and `updated_at`.
7. Open **Project Settings → API Keys** (the exact menu label may vary). Copy the project URL and a **server-side secret key**. Prefer the newer `sb_secret_...` key when available. A legacy `service_role` key can be used only on the server if that is what your project provides. Never expose either key to the browser or GitHub.

The schema enables Row Level Security (RLS) and intentionally creates no public/anonymous table policies. The Express server accesses the table using its server-only key, so browser JavaScript never connects directly to Supabase.

## 7. Configure environment variables

In VS Code, copy `backend/.env.example` to `backend/.env`. On PowerShell, from the project root:

```powershell
Copy-Item backend/.env.example backend/.env
```

Open `backend/.env` and replace the placeholders:

```dotenv
PORT=3000
NODE_ENV=development
SUPABASE_URL=https://YOUR_PROJECT_REF.supabase.co
SUPABASE_SECRET_KEY=your_real_server_side_secret_key
```

- `PORT`: local web server port.
- `NODE_ENV`: application environment.
- `SUPABASE_URL`: URL shown in your Supabase project API settings.
- `SUPABASE_SECRET_KEY`: privileged server-only key from Supabase API Keys.

Do not paste your real credentials into this README, frontend files, screenshots, or GitHub. `.env` is ignored by Git. `.env.example` contains placeholders only and should be committed.

If you accidentally publish a key, revoke/rotate it immediately in Supabase and remove it from repository history as needed.

## 8. Install dependencies and run

Open VS Code → **Terminal → New Terminal**. Run commands from the project root:

```powershell
cd backend
npm install
npm run check
npm run dev
```

- `npm install` downloads the required Node packages and creates `backend/package-lock.json`.
- `npm run check` performs JavaScript syntax checks.
- `npm run dev` starts Node's built-in watch mode and restarts the server when backend files change.

Expected startup message:

```text
Personal Expense Tracker running at http://localhost:3000
```

Keep that terminal open. Visit **http://localhost:3000** in your browser. Do not open `frontend/index.html` directly from File Explorer; the page calls the Express API.

For a non-watch run, use `npm start` from the `backend/` directory.

## 9. Architecture and request flow

1. The browser loads HTML, CSS, and JavaScript from the Express static-file server.
2. `frontend/app.js` uses `fetch()` to call `/api/expenses`.
3. Express routes validate the request and use the Supabase JavaScript client.
4. Supabase PostgreSQL stores the expense records persistently.
5. JSON responses update the dashboard.

The privileged key exists only in `backend/.env` and is read by `backend/supabase.js`. Because the server key can bypass RLS, the backend must be trusted and must not be exposed as an unrestricted public service. This local MVP has no authentication, so anyone who can reach it can view and change the shared expense records. Keep it local or use only non-sensitive demo data.

## 10. API reference

All endpoints return JSON. No authentication is implemented in this MVP.

| Method | Path | Purpose | Request body | Success |
|---|---|---|---|---|
| GET | `/api/health` | Check server/database connection | None | `200` when connected; `503` when unavailable |
| GET | `/api/expenses` | List expenses, newest date first | None | `200 { "data": [...] }` |
| POST | `/api/expenses` | Create expense | JSON expense object | `201 { "data": {...} }` |
| PUT | `/api/expenses/:id` | Update an expense | Full JSON expense object | `200 { "data": {...} }` |
| DELETE | `/api/expenses/:id` | Delete an expense | None | `200 { "message": "...", "id": "..." }` |

Expense request body:

```json
{
  "title": "Lunch",
  "amount": 180,
  "category": "Food",
  "expense_date": "2026-10-29",
  "payment_method": "UPI",
  "notes": "College canteen"
}
```

Allowed categories: `Food`, `Transport`, `Shopping`, `Bills`, `Health`, `Education`, `Entertainment`, `Other`.

Allowed payment methods: `UPI`, `Cash`, `Card`, `Bank transfer`, `Other`.

Common errors: `400` for invalid input/ID, `404` for unknown API route or missing expense, `500` for a database operation error, and `503` when Supabase is not configured. Database error details are not returned to the browser.

## 11. Sample usage

1. Open the app at `http://localhost:3000`.
2. Add an expense such as “Bus fare”, amount `30`, category `Transport`, today's date, payment method `Cash`.
3. Click **Save expense**. It should appear in the list and summary.
4. Change the month filter to inspect another month.
5. Search for “Bus” or filter by `Transport`.
6. Click **Edit**, change the amount, and save.
7. Click **Delete** and confirm. The record should disappear.
8. Refresh the page. Saved records should remain because they are in PostgreSQL.

## 12. Manual testing checklist

- [ ] `GET /api/health` returns `database: connected` after correct configuration.
- [ ] Create a valid expense; it appears in the list and Supabase Table Editor.
- [ ] Refresh; the record remains.
- [ ] Edit title/amount/category; updated values appear.
- [ ] Delete an expense; confirm it disappears from the list and database.
- [ ] Filter by month/category and search by title/notes.
- [ ] Submit empty title, zero/negative amount, invalid date, or invalid category through an API client; server returns `400`.
- [ ] Try updating/deleting a malformed UUID; server returns `400`.
- [ ] Try updating/deleting a well-formed but nonexistent UUID; server returns `404`.
- [ ] Remove or invalidate the Supabase configuration and restart; health should report unavailable and expense API should return `503`.
- [ ] Resize browser to mobile width; forms and list should fit without horizontal page overflow.
- [ ] Confirm `.env` and `node_modules/` are not staged by Git.

## 13. Troubleshooting

**`node` or `npm` is not recognized:** install Node.js LTS, close and reopen VS Code, then rerun the version commands.

**`Cannot find module`:** run `npm install` from `backend/`.

**Database not configured / `503`:** check that `backend/.env` exists, the URL and server-side key are correct, and you restarted the server after editing the file.

**Health says database unavailable:** check that `database/schema.sql` was run in the correct Supabase project, the `expenses` table exists, and the key belongs to that project.

**`401` or `403` from Supabase:** use the correct project's server-side secret key. Do not solve this by creating public RLS policies or putting the key in frontend code.

**Port 3000 is already in use:** set `PORT=3001` in `backend/.env`, restart, and visit `http://localhost:3001`.

**Page loads but records do not:** keep the server terminal open, check `/api/health`, and read the server-side error message. The browser receives a safe generic database error.

**Git shows `.env`:** stop before committing. Confirm `.gitignore` is in the root. If a secret was already committed, rotate it immediately; ignoring the file alone does not remove it from Git history.

## 14. Security considerations and limitations

- This MVP is for local learning and non-sensitive demo data.
- It has no login system or per-user ownership. Anyone who can access the app can manage all records. Do not deploy it publicly as-is.
- The Supabase secret/service-role key bypasses RLS. It is only used server-side, and all database access must go through trusted backend code.
- Before public or multi-user deployment, add Supabase Auth, verify user tokens server-side, add a `user_id` foreign key/column, enforce ownership in every API query, and create suitable RLS policies. Do not simply expose the secret key or add an unrestricted public policy.
- For production, also add authentication, rate limiting, request logging/monitoring, backups, HTTPS, and deployment-specific configuration.
- The app escapes user text before rendering it in HTML and validates inputs on the server; never rely on browser validation alone.

## 15. Future improvements

- Supabase Auth and separate expenses for each user.
- Monthly budgets and budget alerts.
- Income and savings tracking.
- Charts and category-wise reports.
- CSV export and recurring expenses.
- Automated API tests and deployment workflow.

## 16. Upload to GitHub

Create an empty repository at https://github.com/new. Do not initialize it with a README if you already have this project's README.

From the project root:

```bash
git init
git status
git add .
git status
git commit -m "Build personal expense tracker"
git branch -M main
git remote add origin YOUR_GITHUB_REPOSITORY_URL
git push -u origin main
```

Replace `YOUR_GITHUB_REPOSITORY_URL` with your repository URL, such as `https://github.com/YOUR_USERNAME/personal-expense-tracker.git`.

Before `git add .`, verify `.env` is ignored and only `.env.example` is included. Also ensure `node_modules/`, private records, and database exports are not committed. After pushing, open the GitHub repository in your browser and verify the expected folders and files are present.

If Git says the remote already exists, inspect it with `git remote -v` before changing it. If GitHub rejects authentication, follow GitHub's current HTTPS/token or SSH setup instructions; your GitHub password is not a Git password.
