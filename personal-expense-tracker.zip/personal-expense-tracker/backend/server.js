require("dotenv").config();
const path = require("node:path");
const express = require("express");
const helmet = require("helmet");
const { supabase, isDatabaseConfigured } = require("./supabase");
const expenseRoutes = require("./routes/expenses");
const { notFoundHandler, errorHandler } = require("./middleware/error-handler");

const app = express();
const PORT = Number(process.env.PORT) || 3000;
const frontendPath = path.join(__dirname, "..", "frontend");

app.disable("x-powered-by");
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "20kb" }));
app.use(express.static(frontendPath));

app.get("/api/health", async (req, res) => {
  let database = "not_configured";
  if (isDatabaseConfigured) {
    const { error } = await supabase.from("expenses").select("id").limit(1);
    database = error ? "unavailable" : "connected";
  }
  res.status(database === "connected" ? 200 : 503).json({
    status: database === "connected" ? "ok" : "degraded",
    database,
    timestamp: new Date().toISOString()
  });
});

app.use("/api/expenses", expenseRoutes);
app.use("/api", notFoundHandler);
app.use(errorHandler);

app.listen(PORT, () => {
  console.log(`Personal Expense Tracker running at http://localhost:${PORT}`);
  if (!isDatabaseConfigured) {
    console.warn("Supabase is not configured. Add SUPABASE_URL and SUPABASE_SECRET_KEY to backend/.env.");
  }
});

module.exports = app;
