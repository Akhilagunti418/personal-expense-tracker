const express = require("express");
const { randomUUID } = require("node:crypto");
const { supabase, isDatabaseConfigured } = require("../supabase");

const router = express.Router();
const CATEGORIES = ["Food", "Transport", "Shopping", "Bills", "Health", "Education", "Entertainment", "Other"];
const PAYMENT_METHODS = ["UPI", "Cash", "Card", "Bank transfer", "Other"];
const UUID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

function requireDatabase(req, res, next) {
  if (!isDatabaseConfigured) {
    return res.status(503).json({ error: "Database is not configured. Follow the Supabase setup in README.md." });
  }
  next();
}
function validDate(value) {
  if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const date = new Date(`${value}T00:00:00.000Z`);
  return !Number.isNaN(date.getTime()) && date.toISOString().slice(0, 10) === value;
}
function validateExpense(body) {
  const errors = [];
  if (typeof body.title !== "string" || !body.title.trim() || body.title.trim().length > 100) errors.push("Title is required and must be 1–100 characters.");
  const amount = Number(body.amount);
  if (body.amount === "" || body.amount === null || !Number.isFinite(amount) || amount <= 0 || amount > 99999999.99 || Math.round(amount * 100) !== amount * 100) errors.push("Amount must be a positive number with at most two decimal places.");
  if (!CATEGORIES.includes(body.category)) errors.push("Choose a valid category.");
  if (!validDate(body.expense_date)) errors.push("Enter a valid date in YYYY-MM-DD format.");
  if (!PAYMENT_METHODS.includes(body.payment_method)) errors.push("Choose a valid payment method.");
  if (body.notes !== undefined && body.notes !== null && (typeof body.notes !== "string" || body.notes.length > 500)) errors.push("Notes must be 500 characters or fewer.");
  return errors;
}
function toRecord(body) {
  return {
    title: body.title.trim(),
    amount: Number(body.amount).toFixed(2),
    category: body.category,
    expense_date: body.expense_date,
    payment_method: body.payment_method,
    notes: typeof body.notes === "string" && body.notes.trim() ? body.notes.trim() : null
  };
}
function handleDbError(res, error) {
  console.error("Database operation failed:", error.code || "unknown database error");
  return res.status(500).json({ error: "The database operation failed. Check your schema and Supabase configuration." });
}

router.use(requireDatabase);

router.get("/", async (req, res) => {
  const { data, error } = await supabase.from("expenses").select("id,title,amount,category,expense_date,payment_method,notes,created_at,updated_at").order("expense_date", { ascending: false }).order("created_at", { ascending: false });
  if (error) return handleDbError(res, error);
  res.json({ data });
});

router.post("/", async (req, res) => {
  const errors = validateExpense(req.body || {});
  if (errors.length) return res.status(400).json({ error: errors.join(" ") });
  const { data, error } = await supabase.from("expenses").insert({ id: randomUUID(), ...toRecord(req.body) }).select("id,title,amount,category,expense_date,payment_method,notes,created_at,updated_at").single();
  if (error) return handleDbError(res, error);
  res.status(201).json({ data });
});

router.put("/:id", async (req, res) => {
  if (!UUID_PATTERN.test(req.params.id)) return res.status(400).json({ error: "Invalid expense ID." });
  const errors = validateExpense(req.body || {});
  if (errors.length) return res.status(400).json({ error: errors.join(" ") });
  const { data, error } = await supabase.from("expenses").update(toRecord(req.body)).eq("id", req.params.id).select("id,title,amount,category,expense_date,payment_method,notes,created_at,updated_at").maybeSingle();
  if (error) return handleDbError(res, error);
  if (!data) return res.status(404).json({ error: "Expense not found." });
  res.json({ data });
});

router.delete("/:id", async (req, res) => {
  if (!UUID_PATTERN.test(req.params.id)) return res.status(400).json({ error: "Invalid expense ID." });
  const { data, error } = await supabase.from("expenses").delete().eq("id", req.params.id).select("id").maybeSingle();
  if (error) return handleDbError(res, error);
  if (!data) return res.status(404).json({ error: "Expense not found." });
  res.json({ message: "Expense deleted successfully.", id: data.id });
});

module.exports = router;
