function notFoundHandler(req, res) {
  res.status(404).json({ error: "API endpoint not found." });
}
function errorHandler(error, req, res, next) {
  if (res.headersSent) return next(error);
  if (error instanceof SyntaxError && error.status === 400 && "body" in error) {
    return res.status(400).json({ error: "Request body must contain valid JSON." });
  }
  console.error("Unhandled server error:", error.message);
  res.status(500).json({ error: "An unexpected server error occurred." });
}
module.exports = { notFoundHandler, errorHandler };
